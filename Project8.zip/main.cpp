//
// Created by jostl on 11/14/2017.
//

#include "Parse.h"
#include "Project8.h"
#include <iostream>

using namespace std;

int main() {
    set_input("test_grader.blip");
    run();
}